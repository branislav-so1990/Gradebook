<?php
    class Home_model extends CI_Model {

        // loging in
        public function login($username, $password) {
            // validate
            $this->db->where('username', $username);
            $this->db->where('password', $password);
            $result = $this->db->get('user');
            if($result->num_rows() == 1) {
                return $result->row(); // returnig matched user from table
            } else {
                return false; 
            }
        }

    }