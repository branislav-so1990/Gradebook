<?php require_once('header.php') ?>

<h3>Importuj excel fajlove</h3>
<form action="" method="POST" enctype="multipart/form-data"> <br>
    <label for="excel">Izaberi fajl:</label> <br>
    <input type="file" id="excel" name="excel">
    <button type="submit" class="btn btn-primary" >Unesi u bazu</button>
</form>
