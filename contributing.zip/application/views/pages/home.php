<div class="background">
    <div class="loginForm" style="padding-bottom:35px;">
            <img src="<?php echo base_url().'img/logo.png'?>">
            <a href="admin/login" class="btn btn-success">Login</a>
    </div>
</div>
