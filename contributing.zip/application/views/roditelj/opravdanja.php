<?php require_once('header.php') ?>
<?php foreach($staresina as $staresina){} ?>


    <h2>Posaljite opravdanje</h2>

    <div class="opravdanje">
        <form id="opravdanje_form" action="opravdanja" method="POST" enctype="multipart/form-data" onsubmit="return false"> 
            <input type="hidden" name='user_id'      value="<?=$this->session->userdata['user_id'] ?>">
            <input type="hidden" name='staresina_id' value="<?=$staresina->id ?>">
            <input type="hidden" name='razred'       value="<?=$staresina->razred ?>">

            <label><?=(($staresina->razred)<=4)? 'Ucitelj:':'Razredni staresina:'?></label>
            <input class="form-control" type="text" value="<?= $staresina->first_name." ".$staresina->last_name  ?>" readonly>
            
            <label>Sadrzaj poruke:</label>
            <textarea class="form-control" name="opravdanje_sadrzaj" rows="3"></textarea>

            <label>Opravdanje:</label> <br>
            <input type="file" name="opravdanje_file">
            <button type="submit" class="btn btn-success" id="opravdanje_posalji">Posalji</button>
        </form>
    </div> <br>
    <div class="opravdanjaOdg"></div>

    <?php// var_dump($roditelj)?>
   