stari users login<!-- 
<?php// echo validation_errors(); ?>
<?php// echo form_open('users/login', 'class="form-signin"'); ?>
    <h1 class="h3 mb-3 font-weight-normal"><?= $title ?></h1>
    <div class="form-group">
        <label for="">Korisnicko ime</label>
        <input type="text" name="username" class="form-control" placeholder="Unesi korisnicko ime" autofocus>
    </div>
    <div class="form-group">
        <label for="">Sifra</label>
        <input type="password" name="password" class="form-control" placeholder="Unesi sifru">
    </div>
    <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>
<?php //echo form_close(); ?> -->
